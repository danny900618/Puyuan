from django.shortcuts import render
from django.http import JsonResponse,HttpResponseRedirect,HttpResponse
import json
from django.views.decorators.csrf import csrf_exempt
from .models import *
from django.contrib import auth
from django.core.mail import send_mail, send_mass_mail
import uuid,email.message,smtplib,hashlib,random
from django.contrib.sessions.models import Session
import uuid
# Create your views here.
@csrf_exempt #修飾器,一定要加不然會出問題的樣子
def register(request): #def後面就接跟功能相關的單字之類
	if request.method == "POST": #防呆 這邊用到POST,API文件上面有
		data=request.body #這2行是把接收到的格式轉成json格式
		data=str(data,encoding="UTF-8")
		data=json.loads(data)#因為postman需要用json格式才這樣寫
		try:
			account = data["account"]#這邊格式是json格式,postman在用的時候要用raw來測試
			phone = data["phone"]
			password = data["password"]
			email = data["email"]
			uid = uuid.uuid3(uuid.NAMESPACE_DNS,'account')
			invite_code = ''.join(random.sample("0123456789",6))#隨機生成0~9的6位隨機整數
			if UserProfile.objects.get(uid=uid):
				return JsonResponse({'status':'0'})
			else:
				UserProfile.objects.create(uid=uid,account=account,password=password,phone=phone,email=email,invite_code=invite_code)#在資料庫裡新增一筆資料含其資料內容
				UserSet.objects.create(uid=uid)#在資料庫裡新增一筆資料含其資料內容
				HbA1c.objects.create(uid=uid)
				Medical_Information.objects.create(uid=uid)
				Drug_Information.objects.create(uid=uid)
				return JsonResponse({'status':'0'})	
		except:
			message={
				"status":"1"
			}
		return JsonResponse(message)

@csrf_exempt
def login(request): # 登入
	if request.method == "POST":
		account=request.POST.get('account')#這兩行讀使用者輸入的帳號和密碼
		password=request.POST.get('password')
		try:
			user = UserProfile.objects.get(account=account)
			auth_obj = auth.authenticate(request,account=account,password=password)
			if auth_obj:
				request.session.create()
				auth.login(request, auth_obj)
			message = {"status": "0",
			"token":request.session.session_key
			}
			return JsonResponse(message)	
		except:
			return JsonResponse({'status':'1'})	

@csrf_exempt
def logout(request): # 登出
	if request.method == "POST":
		auth.logout(request)
		return HttpResponseRedirect('api/login')

@csrf_exempt
def send(request):  # 傳送驗證信
	if request.method == "POST":
		emaildata=request.POST.get('email')
		profile = UserProfile.objects.get(email=emaildata)
		code = ''.join(random.sample("0123456789",6)) #隨機生成0~9的6位隨機整數
		content = "歡迎使用普元血糖app:\n請點選下列連結完成註冊:\n127.0.0.1:8000/api/check\n驗證碼:{}".format(code)#此行到下面server.close都是寄信的標準格式
		msg = email.message.EmailMessage()
		msg["From"] = "nihandsomeni@gmail.com"
		msg["To"] = request.POST.get('email')
		msg["Subject"] = "普元認證"
		print(msg["To"])
		msg.set_content(content)
		server = smtplib.SMTP_SSL("smtp.gmail.com",465)
		server.login("nihandsomeni@gmail.com","ni123456ni")#這邊是以這組帳號密碼登入發送訊息，一開始要去google帳戶裡面設定>安全性>低安全性應用程式存權設定打開
		server.send_message(msg)
		server.close()
		return JsonResponse({'status':'0'})	

@csrf_exempt
def check(request):  
	if request.method == "POST":
		try:
			code=request.POST.get('code')#使用者輸入的認證碼為code
			phonedata=request.POST.get('phone')
			profile = UserProfile.objects.get(phone=phonedata)#profile來接收 phonedata那一整列
			if profile.code==code:
				return JsonResponse({'status':'0'})
		except:
			return JsonResponse({'status':'1'})
@csrf_exempt
def ForgetPwd(request):
	if request.method == "POST":
		try:
			newpassword = ''.join(random.sample("0123456789",8)) #newpassword #隨機生成0~9的8位隨機整數
			content = "這是您的新密碼:{}".format(newpassword)
			emaildata=request.POST.get('email')#emaildata接收使用者輸入的email
			profile = UserProfile.objects.get(email=emaildata)#找到使用者輸入的EAMIL對應到資料庫那一列
			profile.password = newpassword#將隨機產生8位數密碼更新到那一列的密碼
			profile.save()
			msg = email.message.EmailMessage()
			msg["From"] = "nihandsomeni@gmail.com"
			msg["To"] = request.POST.get('email')
			msg["Subject"] = "普元認證"
			print(msg["To"])
			msg.set_content(content)
			server = smtplib.SMTP_SSL("smtp.gmail.com",465)
			server.login("nihandsomeni@gmail.com","ni123456ni")
			server.send_message(msg)
			server.close()
			return JsonResponse({'status':'0'})	
		except:
			return JsonResponse({'status':'1'})

@csrf_exempt
def ResetPwd(request):  
	if request.method == "POST":
		try:
			passworddata = request.POST.get('password')#使用者輸入忘記密碼產生的新密碼8位數
			profile = UserProfile.objects.get(password=passworddata)#找到使用者新密碼的那一列
			newpassword = request.POST.get('newpassword')#設定新密碼
			profile.password = newpassword#使用者自己訂的密碼更新到那一列的密碼
			profile.save()
			return JsonResponse({'status':'0'})
		except:
			return JsonResponse({'status':'1'})

@csrf_exempt
def recheck(request): #註冊確認uuid.uuid3(uuid.NAMESPACE_DNS, 'python.org')
    if request.method == 'GET':
        user_ck = request.GET["account"]
        try:
            user = UserProfile.objects.get(username=user_ck)
            message = {'status':'1'}
        except:
            message = {'status':'0'}
        return JsonResponse(message)

def privacy_policy(request): # 隱私權聲明 FBLogin
    result = '1'
    try:
        if request.method == 'POST':
            result = '0'
    except:
        pass
    return JsonResponse({'status': result})


# @csrf_exempt
# def user_set(request):  
# 	# data=request.body #這2行是把接收到的格式轉成json格式
# 	# data=str(data,encoding="UTF-8")
# 	if request.method == "PATCH":
# 		try:
# 			name=request.POST('name')
			# birthday=request.POST.get('birthday')
			# height=request.POST.get('height')
			# gender=request.POST.get('gender')
			# address=request.POST.get('address')
			# weight=request.POST.get('weight')
			# phone=request.POST.get('phone')
			# email=request.POST.get('email')
			# UserSet.objects.create(name=name)
# 			user.save()
# 			return JsonResponse({'status':'0'})
# 		except:
# 			return JsonResponse({'status':'1'})	

@csrf_exempt
def User_set(request):
	if request.method == 'PATCH':  #個人資訊上傳
		data = request.body
		data = str(data, encoding="utf-8")
		data=json.loads(data)
		try:
			uid = data['token']
			name = data['name']
			birthday = data['birthday']
			height = data['height']
			gender = data['gender']
			address = data['address']
			weight = data['weight']
			phone = data['phone']
			email = data['email']
			user = UserSet.objects.get(uid=uid)
			user.name = name
			user.birthday=birthday
			user.height=height
			user.gender=gender
			user.address=address
			user.weight=weight
			user.phone=phone
			user.email=email
			user.save()
			message = {"status":"0"}
		except:
			message = {"status":"1"}
		return JsonResponse(message)
		# s.get_decoded()	
		# print(s)
		# sid = request.session.session_key
		# s = Session.objects.get(pk=sid)
		# print(sid)
		# print(s)
	if request.method == 'GET':  #個人資訊
		s = Session.objects.all()[0]
		s.expire_date
		# s.get_decoded()
		print(s)
		# sid = request.COOKIES['sessionid']
		# s = Session.objects.get(pk=sid)
		# s_info = 'Session ID:' + sid + 'Expire_date:' + str(s.expire_date) + 'Data:' + str(s.get_decoded())
		# return JsonResponse(s_info)
		print("123")
		s = Session.objects.get(pk=request.GET['token']).get_decoded()
		try:
			message = {
            "status":"0",
            "user":{
            "id":UserProfiledata.id, 
            "name":UserSetdata.name,
            "account":UserSetdata.name,
            "email":UserSetdata.email}
            # "phone":UserSetdata.phone,
            # "fb_id":UserProfiledata.fb_id,
            # "status":UserSetdata.status,
            # "group":UserSetdata.group,
            # "birthday":UserSetdata.birthday,
            # "height":UserSetdata.height,
            # "weight":UserSetdata.weight,
            # "gender":UserSetdata.gender,
            # "address":UserSetdata.address,
            # "unread_records":[int(UserSetdata.unread_records_one),UserSetdata.unread_records_two,int(UserSetdata.unread_records_three)],
            # "verified":int(UserSetdata.verified),
            # "privacy_policy":UserSetdata.privacy_policy,
            # "must_change_password":1 if UserSetdata.must_change_password else 0,
            # "fcm_id":UserSetdata.fcm_id,
            # "badge":int(UserSetdata.badge),
            # "login_time":int(UserSetdata.login_times),
            # "created_at": datetime.strftime(UserProfiledata.created_at ,"%Y-%m-%d %H:%M:%S"),
            # "updated_at": datetime.strftime(UserProfiledata.updated_at,"%Y-%m-%d %H:%M:%S")},
            # "default":{
            # "id": UserProfiledata.id,
            # "user_id": Userdeflat.uid,
            # "sugar_delta_max": int(Userdeflat.sugar_dalta_max),
            # "sugar_delta_min":int(Userdeflat.sugar_delta_min),
            # "sugar_morning_max": int(Userdeflat.sugar_morning_max),
            # "sugar_morning_min": int(Userdeflat.sugar_morning_min),
            # "sugar_evening_max": int(Userdeflat.sugar_evening_max),
            # "sugar_evening_min": int(Userdeflat.sugar_evening_min),
            # "sugar_before_max": int(Userdeflat.sugar_before_max),
            # "sugar_before_min": int(Userdeflat.sugar_before_min),
            # "sugar_after_max": int(Userdeflat.sugar_after_max),
            # "sugar_after_min":int(Userdeflat.sugar_after_min),
            # "systolic_max": int(Userdeflat.systolic_max),
            # "systolic_min": int(Userdeflat.systolic_min),
            # "diastolic_max": int(Userdeflat.diastolic_max),
            # "diastolic_min":int(Userdeflat.diastolic_min),
            # "pulse_max": int(Userdeflat.pulse_max),
            # "pulse_min":int(Userdeflat.pulse_min),
            # "weight_max": int(Userdeflat.weight_max),
            # "weight_min": int(Userdeflat.weight_min),
            # "bmi_max": int(Userdeflat.bmi_max),
            # "bmi_min": int(Userdeflat.bmi_min),
            # "body_fat_max": int(Userdeflat.body_fat_max),
            # "body_fat_min": int(Userdeflat.body_fat_min),
            # "created_at": datetime.strftime(UserProfiledata.created_at ,"%Y-%m-%d %H:%M:%S"),
            # "updated_at": datetime.strftime(UserProfiledata.updated_at,"%Y-%m-%d %H:%M:%S")}
            # "setting":{
            # "id": UserProfiledata.id,
            # "user_id":Userdeflat.uid,
            # "after_recording": int(UserSetdata.after_recording),
            # "no_recording_for_a_day": int(UserSetdata.no_recording_for_a_day),
            # "over_max_or_under_min": int(UserSetdata.over_max_or_under_min),
            # "after_meal":int(UserSetdata.after_mael),
            # "unit_of_sugar": int(UserSetdata.unit_of_sugar),
            # "unit_of_weight": int(UserSetdata.unit_of_weight),
            # "unit_of_height": int(UserSetdata.unit_of_height),
            # "created_at":datetime.strftime(UserSetdata.created_at ,"%Y-%m-%d %H:%M:%S"),
            # "updated_at": datetime.strftime(UserSetdata.updated_at ,"%Y-%m-%d %H:%M:%S")}
            }
			message = {"status":"0"}
		except:
			message = {"status":"1"}
		return JsonResponse(message)

@csrf_exempt
def User_defult(request):
	if request.method == 'PATCH':  #個人資訊預設值
		data = request.body
		data = str(data, encoding="utf-8")
		data=json.loads(data)
		try:
			# uid = request.user.uid #(在app上測試)
			uid = "0f2541f1-8953-3ed4-9673-fb41519e21c1" #postman測試(直接將1代換成uid)
			user.sugar_delta_max = data['sugar_delta_max']
			user.sugar_delta_min = data['sugar_delta_min']
			user.sugar_morning_max=data['sugar_morning_max']
			user.sugar_morning_min=data['sugar_morning_min']
			user.sugar_evening_max=data['sugar_evening_max']
			user.sugar_evening_min=data['sugar_evening_min']
			user.sugar_before_max=data['sugar_before_max']
			user.sugar_before_min=data['sugar_before_min']
			user.sugar_after_max = data['sugar_after_max']
			user.sugar_after_min = data['sugar_after_min']
			user.systolic_max=data['systolic_max']
			user.systolic_min=data['systolic_min']
			user.diastolic_max=data['diastolic_max']
			user.diastolic_min=data['diastolic_min']
			user.pulse_max=data['pulse_max']
			user.pulse_min=data['pulse_min']
			user.weight_max=data['weight_max']
			user.weight_min=data['weight_min']
			user.bmi_max=data['bmi_max']
			user.bmi_min=data['bmi_min']
			user.body_fat_max=data['body_fat_max']
			user.body_fat_min=data['body_fat_min']

			user.save()
			message = {"status":"0"}
		except:
			message = {"status":"1"}
		return JsonResponse(message)

@csrf_exempt
def User_setting(request):
	if request.method == 'PATCH':  #個人設定
		data = request.body
		data = str(data, encoding="utf-8")
		data=json.loads(data)
		try:
			# uid = request.user.uid #(在app上測試)
			uid = "0f2541f1-8953-3ed4-9673-fb41519e21c1" #postman測試(直接將1代換成uid)
			after_recording = data['after_recording']
			no_recording_for_a_day = data['no_recording_for_a_day']
			over_max_or_under_min = data['over_max_or_under_min']
			after_meal = data['after_meal']
			unit_of_sugar = data['unit_of_sugar']
			unit_of_weight = data['unit_of_weight']
			unit_of_height = data['unit_of_height']

			user = UserSet.objects.get(uid=uid)
			user.after_recording = after_recording
			user.no_recording_for_a_day = no_recording_for_a_day
			user.over_max_or_under_min = over_max_or_under_min
			user.after_meal = after_meal
			user.unit_of_sugar = unit_of_sugar
			user.unit_of_weight = unit_of_weight
			user.unit_of_height = unit_of_height
			message = {"status":"0"}
		except:
			message = {"status":"1"}
		return JsonResponse(message)


@csrf_exempt
def HbA1c(request):
	if request.method == 'GET':  #糖化血色素
		data = request.body
		data = str(data, encoding="utf-8")
		data=json.loads(data)
		try:
			uid = request.user.uid
			message = {
			"status":"0",
			'uid':uid,
			"a1cs":
            {'a1c':a1c,
            'recorded_at':recorded_at,
            'created_at':created_at,
            'updated_at':updated_at,
            'after_recording':after_recording,
            'no_recording_for_a_day':no_recording_for_a_day,
            'over_max_or_under_min':over_max_or_under_min,
            'after_meal':after_meal,
            'unit_of_sugar':unit_of_sugar,
            'unit_of_weight':unit_of_weight,
            "unit_of_height":unit_of_height}
			}
		except:
			message = {"status":"1"}
		return JsonResponse(message)

	if request.method == 'POST':  #糖化血色素上傳
		data = request.body
		data = str(data, encoding="utf-8")
		data=json.loads(data)
		print(data)
		try:
			a1c = data['a1c']
			uid = "0f2541f1-8953-3ed4-9673-fb41519e21"
			aaa = serProfile.objects.get(uid=uid)
			user = HbA1c.objects.get(uid=uid)
			user.a1c = a1c
			user.save()
			message = {"status":"0"}
		except:
			message = {"status":"1"}
		return JsonResponse(message)

