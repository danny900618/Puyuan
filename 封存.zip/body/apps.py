from django.apps import AppConfig


class BodyConfig(AppConfig):
    name = 'body'
